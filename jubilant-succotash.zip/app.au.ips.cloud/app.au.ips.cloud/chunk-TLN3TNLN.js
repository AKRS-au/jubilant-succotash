var n = {
    production: !0
};
export {
    n as a
};